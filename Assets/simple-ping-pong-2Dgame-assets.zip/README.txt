Asset created by Esoe B.Studios.

YouTube: https://www.youtube.com/channel/UCCsuCNggL9EanhfPgvjyGEA
Github: https://www.github.com/myebstudios
Twitter: https://www.twitter.com/myebstudios
Facebook: https://www.facebook.com/myebstudios

Thanks for downloading this asset, Enjoy!! ✌️👨🏽